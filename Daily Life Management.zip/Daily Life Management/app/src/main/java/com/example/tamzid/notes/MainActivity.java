package com.example.tamzid.notes;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText title,notes;
    Button save,show;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        title = (EditText) findViewById(R.id.editText);
        notes = (EditText) findViewById(R.id.editText2);
        save = (Button) findViewById(R.id.button);
        show = (Button) findViewById(R.id.button2);

        final DatabaseFunction df = new DatabaseFunction(getApplicationContext());

        save.setOnClickListener(new View.OnClickListener() {
            @Override
           final public void onClick(View view) {
                String t = title.getText().toString();
                String n = notes.getText().toString();
                GS gs = new GS(t,n);
                df.addingData(gs);
                Intent intent = new Intent(getApplicationContext(), Notes.class);
                startActivity(intent);

                Toast.makeText(getApplicationContext(), "Saved", Toast.LENGTH_LONG).show();
            }
        });

        show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Notes.class);
                startActivity(intent);
            }
        });
    }
}
