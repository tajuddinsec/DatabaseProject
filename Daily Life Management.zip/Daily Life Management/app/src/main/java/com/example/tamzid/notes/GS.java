package com.example.tamzid.notes;



public class GS {
    int id;
    String title, notes;
    public GS(String t, String n) {
        title = t;
        notes = n;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getNotes() {
        return notes;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
}
