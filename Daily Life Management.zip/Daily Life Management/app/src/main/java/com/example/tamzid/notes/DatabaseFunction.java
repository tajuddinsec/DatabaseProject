package com.example.tamzid.notes;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Arafat  Kamal on 11-Nov-17.
 */

public class DatabaseFunction extends SQLiteOpenHelper {

    private static final String DB_Name = "myDB";
    private static final String Table_Name = "myNotes";
    private static final String ID = "id";
    private static final String Title = "title";
    private static final String Notes = "notes";


    public DatabaseFunction(Context context) {

        super(context, DB_Name, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String s = "CREATE TABLE "+Table_Name+" ("+ID+" INTEGER PRIMARY KEY, "+Title+" TEXT, "+Notes+" TEXT)";
        sqLiteDatabase.execSQL(s);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }


    void addingData(GS gs) {
        SQLiteDatabase sqd = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(Title,gs.getTitle());
        cv.put(Notes,gs.getNotes());

        sqd.insert(Table_Name, null, cv);
        sqd.close();
    }

    String[] showData() {
        SQLiteDatabase sq = this.getWritableDatabase();

        String select = "SELECT * FROM "+Table_Name;
        Cursor cursor = sq.rawQuery(select,null );
        String[] receivedData = new String[cursor.getCount()];
        cursor.moveToFirst();
        if(cursor.moveToFirst()){
            int counter =0;
             do {
                receivedData[counter] = cursor.getString(cursor.getColumnIndex(Title+"")) + "\n\n" + cursor.getString(cursor.getColumnIndex(Notes+""));
                counter++;
            }while (cursor.moveToNext());
        }
        return receivedData;

    }

    String fetch_note(int id) {
        SQLiteDatabase sq = this.getReadableDatabase();

        String q = "SELECT "+Notes+" FROM "+Table_Name+" WHERE "+ID+" = "+ id ;

        Cursor c = sq.rawQuery(q, null);
        String s = "";
        c.moveToFirst();

        if(c.moveToFirst()) {
            s = c.getString(c.getColumnIndex(Notes+""));
        }

        return  s;

    }

    int updateNote(int id, String notes) {
        SQLiteDatabase sq = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(Notes, notes);
        return  sq.update(Table_Name, cv, ID+" = ? ", new String[]{id+""});
    }

    int deleteNote(String notes) {
        SQLiteDatabase s = this.getWritableDatabase();

        return s.delete(Table_Name, Notes+" = ?", new String[] {notes});
    }
}
